if (typeof SiftCore === "undefined" && typeof importScripts === "function") {
  importScripts("shared.js");
}

const { DEFAULT_SETTINGS } = SiftCore;

chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "open-options") {
    chrome.runtime.openOptionsPage();
  }
  if (message?.type === "open-welcome") {
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
  }
  if (message?.type === "open-extensions") {
    chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` });
  }
});

// Settings used to live in chrome.storage.local. Copy them into sync once so
// existing users keep their feed when 1.0.1 starts following them across
// devices. Local counters are left where they are.
function migrateSettingsToSync() {
  if (!chrome.storage.sync) return;
  const keys = Object.keys(DEFAULT_SETTINGS);
  chrome.storage.sync.get(keys, (synced) => {
    if (chrome.runtime.lastError) return;
    const alreadySynced = keys.some((key) => synced[key] !== undefined);
    if (alreadySynced) return;
    chrome.storage.local.get(keys, (local) => {
      if (chrome.runtime.lastError) return;
      const values = {};
      for (const key of keys) {
        if (local[key] !== undefined) values[key] = local[key];
      }
      if (Object.keys(values).length === 0) return;
      chrome.storage.sync.set(values, () => {
        if (chrome.runtime.lastError) return;
        chrome.storage.local.remove(keys);
      });
    });
  });
}

chrome.runtime.onInstalled.addListener((details) => {
  migrateSettingsToSync();
  if (details.reason !== "install") return;
  chrome.storage.local.get({ onboardingComplete: false }, (stored) => {
    if (stored.onboardingComplete) return;
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
  });
});

chrome.runtime.onStartup.addListener(migrateSettingsToSync);
