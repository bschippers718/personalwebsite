const {
  DEFAULT_SETTINGS,
  STARTER_PACKS,
  applyStarterPack,
  starterPackIsApplied,
  splitEntries,
  parseHandles,
  getFeedInfo,
  getConflictingTerms
} = SiftCore;

const FIELD_IDS = Object.keys(DEFAULT_SETTINGS);
const form = document.querySelector("#settings");
const settingsFields = document.querySelector("#settingsFields");
const status = document.querySelector("#status");
const profileSummary = document.querySelector("#profileSummary");
const feedUrlStatus = document.querySelector("#feedUrlStatus");
const formIssues = document.querySelector("#formIssues");
const saveButton = document.querySelector("#save");
const openFeedButton = document.querySelector("#openFeed");
const resetButton = document.querySelector("#reset");
const packGrid = document.querySelector("#starterPackGrid");
const packStatus = document.querySelector("#packStatus");
const listNudge = document.querySelector("#listNudge");
const enabledInput = document.querySelector("#enabled");
const openWelcomeButton = document.querySelector("#openWelcome");

let isLoaded = false;
let isDirty = false;
let isSaving = false;
let editRevision = 0;
let packsEnabled = false;

function field(id) {
  return document.getElementById(id);
}

function readForm() {
  const values = {};

  for (const id of FIELD_IDS) {
    const input = field(id);
    if (input.type === "checkbox") {
      values[id] = input.checked;
    } else if (input.type === "number") {
      values[id] =
        input.value.trim() === "" ? 0 : Number.parseInt(input.value, 10);
    } else {
      values[id] = input.value;
    }
  }

  values.profileName = values.profileName.trim() || "My Feed";
  return values;
}

function fillForm(values) {
  for (const id of FIELD_IDS) {
    const input = field(id);
    const value = values[id];
    if (input.type === "checkbox") {
      input.checked = Boolean(value);
    } else {
      input.value = value;
    }
  }
  renderPackGrid(values.topicKeywords || "");
  updatePageState();
}

function setInteractive(enabled) {
  settingsFields.disabled = !enabled;
  enabledInput.disabled = !enabled;
  packsEnabled = enabled;
  resetButton.disabled = !enabled;
  openWelcomeButton.disabled = !enabled;
  packGrid
    ?.querySelectorAll(".pack-button")
    .forEach((button) => {
      button.disabled = !enabled || button.classList.contains("is-applied");
    });
  document.body.classList.toggle("loading", !enabled);
}

function renderPackGrid(topicKeywords = "") {
  if (!packGrid) return;
  packGrid.replaceChildren();
  let appliedCount = 0;

  for (const pack of STARTER_PACKS) {
    const applied = starterPackIsApplied(pack, topicKeywords);
    if (applied) appliedCount += 1;

    const button = document.createElement("button");
    button.type = "button";
    button.className = `pack-button${applied ? " is-applied" : ""}`;
    button.dataset.packId = pack.id;
    button.disabled = !packsEnabled || applied;
    button.setAttribute("aria-pressed", applied ? "true" : "false");

    const name = document.createElement("strong");
    name.textContent = pack.name;
    const blurb = document.createElement("span");
    blurb.textContent = pack.blurb;
    const state = document.createElement("em");
    state.textContent = applied ? "Added" : "Add";
    button.append(name, blurb, state);

    button.addEventListener("click", () => {
      if (!packsEnabled || applied) return;
      const next = applyStarterPack(readForm(), pack);
      fillForm(next);
      markDirty();
      setStatus(`${pack.name} pack added—review topics, then save`, "warning");
    });

    packGrid.append(button);
  }

  if (packStatus) {
    packStatus.textContent =
      appliedCount === 0
        ? "No packs added yet"
        : `${appliedCount} pack${appliedCount === 1 ? "" : "s"} in your topics`;
  }
  updateListNudge();
}

function updateListNudge() {
  if (!listNudge) return;
  const values = isLoaded ? readForm() : {};
  const topics = splitEntries(values.topicKeywords || "").length;
  const feedInfo = getFeedInfo(values.feedUrl || "");
  const show =
    packsEnabled && topics > 0 && !(feedInfo.isList && feedInfo.isValid);
  listNudge.hidden = !show;
}

function setStatus(message, tone = "neutral") {
  status.textContent = message;
  status.className = `visible ${tone}`;
}

function validate(values) {
  const errors = [];
  const feedInfo = getFeedInfo(values.feedUrl);
  const conflicts = getConflictingTerms(values);
  const topicCount = splitEntries(values.topicKeywords).length;
  const priorityHandles = parseHandles(values.trustedHandles);
  const hiddenHandles = parseHandles(values.hiddenHandles);
  const accountConflicts = [...priorityHandles].filter((handle) =>
    hiddenHandles.has(handle)
  );
  const limit = values.maxPostsPerAuthor;

  if (!feedInfo.isValid) {
    errors.push(feedInfo.error);
  }

  if (values.requireTopicMatch && topicCount === 0) {
    errors.push(
      "Add at least one wanted topic or turn off topic-only filtering."
    );
  }

  if (conflicts.length > 0) {
    errors.push(
      `Remove these exact duplicates from either wanted or blocked topics: ${conflicts.join(", ")}.`
    );
  }

  if (accountConflicts.length > 0) {
    errors.push(
      `These accounts cannot be both priority and never-show: ${accountConflicts
        .map((handle) => `@${handle}`)
        .join(", ")}.`
    );
  }

  if (!Number.isInteger(limit) || limit < 0 || limit > 100) {
    errors.push("Maximum posts per account must be a whole number from 0 to 100.");
  }

  return { errors, feedInfo, topicCount };
}

function renderIssues(errors) {
  formIssues.replaceChildren();
  formIssues.hidden = errors.length === 0;

  if (errors.length === 0) return;

  const title = document.createElement("strong");
  title.textContent = "Fix these settings before saving:";
  formIssues.append(title);

  const list = document.createElement("ul");
  for (const error of errors) {
    const item = document.createElement("li");
    item.textContent = error;
    list.append(item);
  }
  formIssues.append(list);
}

function updatePageState() {
  if (!isLoaded) return;

  const values = readForm();
  const { errors, feedInfo, topicCount } = validate(values);
  const name = values.profileName;
  const sourceLabel = feedInfo.isList
    ? "opens an X List"
    : feedInfo.isValid
      ? "using Following"
      : "List URL needs attention";

  profileSummary.textContent =
    `${name} · ${topicCount} topic${topicCount === 1 ? "" : "s"}` +
    ` · ${sourceLabel}`;
  openFeedButton.textContent = `Open ${name}`;

  field("feedUrl").setAttribute(
    "aria-invalid",
    String(!feedInfo.isValid)
  );
  feedUrlStatus.textContent = feedInfo.isValid
    ? feedInfo.isList
      ? "X supplies posts from this List; Sift then applies your rules."
      : topicCount > 0
        ? "Topic packs work best with a List. Paste an x.com/i/lists/… URL above."
        : "No List selected—Sift applies your rules to the Following timeline."
    : feedInfo.error;
  feedUrlStatus.className = feedInfo.isValid ? "field-status" : "field-status error";
  updateListNudge();

  renderIssues(errors);
  saveButton.disabled = !isDirty || isSaving || errors.length > 0;
  openFeedButton.disabled = isSaving || errors.length > 0 || !values.enabled;
}

function markDirty() {
  if (!isLoaded) return;
  editRevision += 1;
  isDirty = true;
  setStatus("Unsaved changes", "warning");
  updatePageState();
}

function saveSettings(onSaved) {
  if (!isLoaded || isSaving) return;

  const values = readForm();
  const { errors, feedInfo } = validate(values);
  if (errors.length > 0) {
    setStatus("Resolve the highlighted settings first", "error");
    updatePageState();
    return;
  }

  if (feedInfo.isList) {
    values.feedUrl = feedInfo.url;
  }

  const savedRevision = editRevision;
  isSaving = true;
  setStatus("Saving…");
  updatePageState();

  chrome.storage.local.set(values, () => {
    isSaving = false;
    if (chrome.runtime.lastError) {
      setStatus("Settings could not be saved", "error");
      updatePageState();
      return;
    }

    if (editRevision === savedRevision) {
      isDirty = false;
      fillForm(values);
      setStatus("All changes saved", "success");
    } else {
      isDirty = true;
      setStatus("Earlier changes saved; newer edits still need saving", "warning");
      updatePageState();
    }
    onSaved?.(values);
  });
}

function openFeed(values = readForm()) {
  const feedInfo = getFeedInfo(values.feedUrl);
  if (!feedInfo.isValid) {
    setStatus("Fix the X List URL before opening the feed", "error");
    updatePageState();
    return;
  }
  chrome.tabs.create({ url: feedInfo.url });
}

setInteractive(false);

chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
  if (chrome.runtime.lastError) {
    setStatus("Settings could not be loaded", "error");
    return;
  }

  isLoaded = true;
  fillForm({ ...DEFAULT_SETTINGS, ...stored });
  setInteractive(true);
  setStatus("All changes saved", "success");
  updatePageState();
});

for (const id of FIELD_IDS) {
  field(id).addEventListener("input", markDirty);
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  saveSettings();
});

saveButton.addEventListener("click", () => saveSettings());

openFeedButton.addEventListener("click", () => {
  if (isDirty) {
    saveSettings(openFeed);
  } else {
    openFeed();
  }
});

resetButton.addEventListener("click", () => {
  if (!window.confirm("Restore every setting to its default value?")) return;
  fillForm(DEFAULT_SETTINGS);
  markDirty();
  setStatus("Defaults restored—save to apply them", "warning");
});

openWelcomeButton.addEventListener("click", () => {
  window.location.href = chrome.runtime.getURL("welcome.html");
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (!isLoaded || areaName !== "local" || isSaving) return;

  if (isDirty) {
    setStatus(
      "Settings changed elsewhere; your unsaved edits are preserved",
      "warning"
    );
    return;
  }

  const current = readForm();
  for (const [key, change] of Object.entries(changes)) {
    if (FIELD_IDS.includes(key)) current[key] = change.newValue;
  }
  fillForm(current);
  setStatus("Settings updated", "success");
});

window.addEventListener("beforeunload", (event) => {
  if (!isDirty) return;
  event.preventDefault();
  event.returnValue = "";
});
