const {
  DEFAULT_SETTINGS,
  STARTER_PACKS,
  applyStarterPack,
  starterPackIsApplied,
  getFeedInfo,
  splitEntries
} = SiftCore;

const footerStatus = document.querySelector("#footerStatus");
const footerDetail = document.querySelector("#footerDetail");
const packStatus = document.querySelector("#packStatus");
const packGrid = document.querySelector("#starterPackGrid");
const openFeedButton = document.querySelector("#openFeed");
const finishButton = document.querySelector("#finish");
const openSettingsEarly = document.querySelector("#openSettingsEarly");
const listUrlInput = document.querySelector("#listUrlInput");
const saveListUrlButton = document.querySelector("#saveListUrl");
const listUrlStatus = document.querySelector("#listUrlStatus");
const skipListButton = document.querySelector("#skipList");
const sourceFoot = document.querySelector("#sourceFoot");
const readFoot = document.querySelector("#readFoot");
const checklist = document.querySelector("#setupChecklist");

let skippedList = false;

function setFooter(title, detail) {
  footerStatus.textContent = title;
  if (detail) footerDetail.textContent = detail;
}

function markOnboardingSeen() {
  return chrome.storage.local.set({ onboardingComplete: true });
}

function openOptions() {
  markOnboardingSeen();
  chrome.runtime.openOptionsPage();
}

function resolveFeedUrl(stored) {
  const info = getFeedInfo(stored.feedUrl || "");
  if (info.isList && info.isValid) return info.url;
  return "https://x.com/home";
}

function openFeed(url) {
  markOnboardingSeen();
  chrome.tabs.create({ url: url || "https://x.com/home" });
}

function setupState(stored) {
  const packCount = STARTER_PACKS.filter((pack) =>
    starterPackIsApplied(pack, stored.topicKeywords || "")
  ).length;
  const topicCount = splitEntries(stored.topicKeywords || "").length;
  const feedInfo = getFeedInfo(stored.feedUrl || "");
  const hasList = Boolean(feedInfo.isList && feedInfo.isValid);
  const hasTopics = packCount > 0 || topicCount > 0;
  return { packCount, topicCount, hasList, hasTopics, feedInfo };
}

function updateChecklist(state) {
  const items = {
    topics: state.hasTopics,
    source: state.hasList || skippedList,
    read: false
  };
  let current = "topics";
  if (state.hasTopics && !items.source) current = "source";
  if (state.hasTopics && items.source) current = "read";

  checklist.querySelectorAll("li").forEach((item) => {
    const key = item.dataset.step;
    item.classList.toggle("is-done", Boolean(items[key]));
    item.classList.toggle("is-current", key === current && !items[key]);
  });

  document.querySelectorAll(".step-card").forEach((card) => {
    const key = card.dataset.card;
    card.classList.toggle("is-complete", Boolean(items[key]));
    card.classList.toggle("is-current", key === current);
  });
}

function updateGuidance(stored) {
  const state = setupState(stored);
  updateChecklist(state);

  if (state.hasList) {
    listUrlInput.value = state.feedInfo.url;
    listUrlStatus.textContent = "List saved. Step 3 will open this feed.";
    sourceFoot.textContent = "List connected";
    skippedList = false;
  } else if (skippedList) {
    listUrlStatus.textContent =
      "Using Following for now. A List will usually work better.";
    sourceFoot.textContent = "Following selected";
  } else {
    listUrlStatus.textContent = "";
    sourceFoot.textContent = state.hasTopics
      ? "Do this next for a useful feed"
      : "Recommended after you pick topics";
  }

  if (!state.hasTopics) {
    readFoot.textContent = "Choose topics in Step 1 first";
    setFooter(
      "Start with Step 1",
      "Pick topics first. Then add a List so X loads matching posts."
    );
    finishButton.textContent = "Finish and open feed";
    return;
  }

  if (!state.hasList && !skippedList) {
    readFoot.textContent = "Add a List in Step 2, then open your feed";
    setFooter(
      "Next: add an X List",
      "Topic packs on Following often look empty. A focused List fixes that."
    );
    finishButton.textContent = "Open Following anyway";
    return;
  }

  readFoot.textContent = state.hasList
    ? "Ready—open your List feed"
    : "Ready—open Following";
  setFooter(
    state.hasList ? "Ready to read your List" : "Ready to try Following",
    state.hasList
      ? "Sift will open your saved List and apply your topics there."
      : "You can add a List later in Settings if the feed feels empty."
  );
  finishButton.textContent = state.hasList
    ? "Finish and open List"
    : "Finish and open Following";
}

function renderPackGrid(stored) {
  const topicKeywords = stored.topicKeywords || "";
  packGrid.replaceChildren();
  let appliedCount = 0;

  for (const pack of STARTER_PACKS) {
    const applied = starterPackIsApplied(pack, topicKeywords);
    if (applied) appliedCount += 1;

    const button = document.createElement("button");
    button.type = "button";
    button.className = `pack-button${applied ? " is-applied" : ""}`;
    button.dataset.packId = pack.id;
    button.setAttribute("aria-pressed", applied ? "true" : "false");

    const name = document.createElement("strong");
    name.textContent = pack.name;
    const blurb = document.createElement("span");
    blurb.textContent = pack.blurb;
    const stateLabel = document.createElement("em");
    stateLabel.textContent = applied ? "Added" : "Add";
    button.append(name, blurb, stateLabel);

    button.addEventListener("click", () => {
      if (starterPackIsApplied(pack, topicKeywords)) return;
      chrome.storage.local.get(DEFAULT_SETTINGS, (current) => {
        const next = applyStarterPack(
          { ...DEFAULT_SETTINGS, ...current },
          pack
        );
        chrome.storage.local.set(next, () => {
          renderPackGrid(next);
          updateGuidance(next);
          document.querySelector('[data-card="source"]')?.scrollIntoView({
            behavior: "smooth",
            block: "nearest"
          });
        });
      });
    });

    packGrid.append(button);
  }

  packStatus.textContent =
    appliedCount === 0
      ? "Pick the topics you care about"
      : `${appliedCount} pack${appliedCount === 1 ? "" : "s"} added · next: List`;
}

function refreshFromStorage() {
  chrome.storage.local.get(
    { ...DEFAULT_SETTINGS, onboardingComplete: false },
    (stored) => {
      renderPackGrid(stored);
      updateGuidance(stored);
    }
  );
}

saveListUrlButton.addEventListener("click", () => {
  const info = getFeedInfo(listUrlInput.value);
  if (!info.hasValue) {
    listUrlStatus.textContent = "Paste a List URL from x.com/i/lists/…";
    return;
  }
  if (!info.isValid || !info.isList) {
    listUrlStatus.textContent =
      info.error || "Use a valid X List URL like https://x.com/i/lists/123";
    return;
  }

  chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
    const next = { ...DEFAULT_SETTINGS, ...stored, feedUrl: info.url };
    chrome.storage.local.set(next, () => {
      skippedList = false;
      updateGuidance(next);
      document.querySelector('[data-card="read"]')?.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
      });
    });
  });
});

skipListButton.addEventListener("click", () => {
  skippedList = true;
  chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
    updateGuidance({ ...DEFAULT_SETTINGS, ...stored });
  });
});

function finishSetup() {
  chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
    const state = setupState(stored);
    if (!state.hasTopics) {
      setFooter(
        "Pick at least one topic pack first",
        "Without topics, Sift has nothing useful to keep."
      );
      return;
    }
    openFeed(resolveFeedUrl(stored));
  });
}

openFeedButton.addEventListener("click", finishSetup);
finishButton.addEventListener("click", finishSetup);

openSettingsEarly.addEventListener("click", (event) => {
  event.preventDefault();
  openOptions();
});

document.querySelector('a.secondary[href="options.html"]')?.addEventListener(
  "click",
  (event) => {
    event.preventDefault();
    openOptions();
  }
);

refreshFromStorage();
