(function initializeSiftCore(global) {
  const DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    profileName: "My Feed",
    feedUrl: "",
    topicKeywords: "",
    requireTopicMatch: false,
    defaultToFollowing: true,
    distractionFree: true,
    hidePromoted: true,
    hideReposts: false,
    hideQuotes: false,
    hidePostsWithoutLinks: false,
    maxPostsPerAuthor: 0,
    mutedKeywords: "",
    hiddenHandles: "",
    trustedHandles: ""
  });

  const COMMON_MUTES = ["giveaway", "memecoin", "crypto airdrop", "follow for follow"];

  const STARTER_PACKS = Object.freeze([
    Object.freeze({
      id: "tesla",
      name: "Tesla",
      blurb: "Cars, FSD, Optimus, factories",
      topicKeywords: [
        "Tesla",
        "Model 3",
        "Model Y",
        "Model S",
        "Model X",
        "Cybertruck",
        "FSD",
        "Full Self-Driving",
        "Optimus",
        "Supercharger",
        "Gigafactory",
        "4680"
      ].join("\n"),
      trustedHandles: ["@Tesla"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "spacex",
      name: "SpaceX",
      blurb: "Starship, Starlink, launches",
      topicKeywords: [
        "SpaceX",
        "Starship",
        "Starlink",
        "Falcon 9",
        "Falcon Heavy",
        "Dragon",
        "Raptor",
        "Starbase",
        "Crew Dragon"
      ].join("\n"),
      trustedHandles: ["@SpaceX", "@Starlink"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "ai",
      name: "AI",
      blurb: "Models, agents, research labs",
      topicKeywords: [
        "AI",
        "artificial intelligence",
        "LLM",
        "GPT",
        "Claude",
        "Gemini",
        "OpenAI",
        "Anthropic",
        "DeepMind",
        "agents",
        "machine learning"
      ].join("\n"),
      trustedHandles: ["@OpenAI", "@AnthropicAI", "@GoogleDeepMind"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "technology",
      name: "Technology",
      blurb: "Gadgets, software, big tech",
      topicKeywords: [
        "technology",
        "software",
        "Apple",
        "Google",
        "Microsoft",
        "Android",
        "iPhone",
        "chip",
        "semiconductor",
        "cloud computing"
      ].join("\n"),
      trustedHandles: ["@Apple", "@Google", "@Microsoft"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "vc",
      name: "VC Funding",
      blurb: "Term sheets, rounds, founders",
      topicKeywords: [
        "venture capital",
        "Series A",
        "Series B",
        "seed round",
        "funding round",
        "term sheet",
        "startup funding",
        "IPO",
        "valuation"
      ].join("\n"),
      trustedHandles: ["@a16z", "@sequoia", "@ycombinator"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "finance",
      name: "Finance",
      blurb: "Markets, Fed, earnings, banks",
      topicKeywords: [
        "stocks",
        "markets",
        "Federal Reserve",
        "interest rates",
        "earnings",
        "inflation",
        "Wall Street",
        "S&P 500",
        "bonds"
      ].join("\n"),
      trustedHandles: ["@WSJ", "@Bloomberg", "@CNBC"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "sports",
      name: "Sports",
      blurb: "Scores, trades, game day",
      topicKeywords: [
        "NFL",
        "NBA",
        "MLB",
        "NHL",
        "Premier League",
        "March Madness",
        "transfer news",
        "playoffs",
        "World Cup"
      ].join("\n"),
      trustedHandles: ["@espn", "@NFL", "@NBA"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 4
    }),
    Object.freeze({
      id: "gaming",
      name: "Gaming",
      blurb: "Consoles, PC, esports, drops",
      topicKeywords: [
        "gaming",
        "PlayStation",
        "Xbox",
        "Nintendo",
        "Steam",
        "esports",
        "game release",
        "Game Pass",
        "Switch"
      ].join("\n"),
      trustedHandles: ["@PlayStation", "@Xbox", "@NintendoAmerica"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "science",
      name: "Science",
      blurb: "Research, space, biology, physics",
      topicKeywords: [
        "science",
        "research paper",
        "physics",
        "biology",
        "astronomy",
        "NASA",
        "clinical trial",
        "peer reviewed",
        "Nobel"
      ].join("\n"),
      trustedHandles: ["@NASA", "@nature", "@ScienceMagazine"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    }),
    Object.freeze({
      id: "climate",
      name: "Climate & Energy",
      blurb: "Clean power, grids, policy",
      topicKeywords: [
        "climate",
        "renewable energy",
        "solar power",
        "wind power",
        "nuclear energy",
        "EV charging",
        "grid",
        "carbon",
        "battery storage"
      ].join("\n"),
      trustedHandles: ["@IEA", "@UNFCCC"].join("\n"),
      mutedKeywords: COMMON_MUTES.join("\n"),
      maxPostsPerAuthor: 3
    })
  ]);

  function splitEntries(value) {
    return String(value || "")
      .split(/\r?\n/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  function normalizeTerm(value) {
    return String(value || "")
      .normalize("NFKC")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeHandle(value) {
    return String(value || "").trim().toLowerCase().replace(/^@/, "");
  }

  function parseTerms(value) {
    return [...new Set(splitEntries(value).map(normalizeTerm).filter(Boolean))];
  }

  function parseHandles(value) {
    return new Set(
      splitEntries(value).map(normalizeHandle).filter(Boolean)
    );
  }

  function termMatches(normalizedText, normalizedTerm) {
    if (!normalizedText || !normalizedTerm) return false;
    return ` ${normalizedText} `.includes(` ${normalizedTerm} `);
  }

  function matchingTerm(normalizedText, terms) {
    return terms.find((term) => termMatches(normalizedText, term)) || "";
  }

  function mergeEntries(...values) {
    const merged = [];
    const seen = new Set();

    for (const entry of values.flatMap(splitEntries)) {
      const key = normalizeTerm(entry);
      if (!key || seen.has(key)) continue;
      seen.add(key);
      merged.push(entry);
    }

    return merged.join("\n");
  }

  function getStarterPack(id) {
    return STARTER_PACKS.find((pack) => pack.id === id) || null;
  }

  function mergeStarterTopics(...ids) {
    return mergeEntries(
      ...ids.map((id) => getStarterPack(id)?.topicKeywords || "")
    );
  }

  function mergeStarterHandles(...ids) {
    return mergeEntries(
      ...ids.map((id) => getStarterPack(id)?.trustedHandles || "")
    );
  }

  function starterPackIsApplied(pack, topicKeywords) {
    const existing = new Set(parseTerms(topicKeywords));
    const packTerms = parseTerms(pack.topicKeywords);
    if (packTerms.length === 0) return false;
    const matched = packTerms.filter((term) => existing.has(term)).length;
    return matched >= Math.min(3, packTerms.length);
  }

  function applyStarterPack(current, pack) {
    const next = {
      ...current,
      topicKeywords: mergeEntries(current.topicKeywords, pack.topicKeywords),
      mutedKeywords: mergeEntries(current.mutedKeywords, pack.mutedKeywords),
      trustedHandles: mergeEntries(
        current.trustedHandles,
        pack.trustedHandles
      ),
      requireTopicMatch: true,
      hidePromoted: true,
      maxPostsPerAuthor:
        Number(current.maxPostsPerAuthor) > 0
          ? current.maxPostsPerAuthor
          : pack.maxPostsPerAuthor
    };

    if (
      !current.profileName ||
      current.profileName === DEFAULT_SETTINGS.profileName
    ) {
      next.profileName = pack.name;
    }

    return next;
  }

  const TESLA_SPACEX_STARTER = Object.freeze({
    profileName: "Tesla + SpaceX",
    topicKeywords: mergeStarterTopics("tesla", "spacex"),
    requireTopicMatch: true,
    mutedKeywords: COMMON_MUTES.join("\n"),
    trustedHandles: mergeStarterHandles("tesla", "spacex"),
    hidePromoted: true,
    hideReposts: false,
    maxPostsPerAuthor: 3
  });

  function getFeedInfo(value) {
    const raw = String(value || "").trim();
    if (!raw) {
      return {
        url: "https://x.com/home",
        hasValue: false,
        isValid: true,
        isList: false,
        error: ""
      };
    }

    try {
      const withProtocol = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
      const url = new URL(withProtocol);
      const allowedHosts = new Set([
        "x.com",
        "www.x.com",
        "twitter.com",
        "www.twitter.com"
      ]);
      const isAllowedHost =
        url.protocol === "https:" &&
        allowedHosts.has(url.hostname) &&
        !url.username &&
        !url.password &&
        !url.port;
      const pathname = url.pathname.replace(/\/+$/, "");
      const isList =
        /^\/i\/lists\/\d+$/.test(pathname) ||
        /^\/[A-Za-z0-9_]{1,15}\/lists\/[^/]+$/.test(pathname);

      if (!isAllowedHost || !isList) {
        return {
          url: "https://x.com/home",
          hasValue: true,
          isValid: false,
          isList: false,
          error: "Paste an X List URL, such as https://x.com/i/lists/123."
        };
      }

      return {
        url: `https://x.com${pathname}`,
        pathname,
        hasValue: true,
        isValid: true,
        isList: true,
        error: ""
      };
    } catch {
      return {
        url: "https://x.com/home",
        hasValue: true,
        isValid: false,
        isList: false,
        error: "Paste a complete X List URL."
      };
    }
  }

  function isActiveFeedPath(pathname, feedUrl) {
    const currentPath = String(pathname || "").replace(/\/+$/, "") || "/";
    if (currentPath === "/home") return true;

    const feedInfo = getFeedInfo(feedUrl);
    return feedInfo.isList && currentPath === feedInfo.pathname;
  }

  function compileRules(settings) {
    return {
      topicKeywords: parseTerms(settings.topicKeywords),
      mutedKeywords: parseTerms(settings.mutedKeywords),
      trustedHandles: parseHandles(settings.trustedHandles),
      hiddenHandles: parseHandles(settings.hiddenHandles),
      limit: Number(settings.maxPostsPerAuthor)
    };
  }

  function getConflictingTerms(settings) {
    const wanted = new Set(parseTerms(settings.topicKeywords));
    return parseTerms(settings.mutedKeywords).filter((term) => wanted.has(term));
  }

  function getHideReason(post, settings, rules, authorCounts) {
    if (settings.hidePromoted && post.isPromoted) {
      return "Promoted post";
    }

    if (post.handle && rules.hiddenHandles.has(post.handle)) {
      return `Never-show account @${post.handle}`;
    }

    const blockedTerm = matchingTerm(post.normalizedText, rules.mutedKeywords);
    if (blockedTerm) {
      return `Blocked phrase “${blockedTerm}”`;
    }

    if (settings.hideReposts && post.isRepost) {
      return "Repost";
    }

    if (settings.hideQuotes && post.isQuote) {
      return "Quote post";
    }

    const isPriorityAccount =
      post.handle && rules.trustedHandles.has(post.handle);
    if (
      settings.requireTopicMatch &&
      rules.topicKeywords.length > 0 &&
      !isPriorityAccount &&
      !matchingTerm(post.normalizedText, rules.topicKeywords)
    ) {
      return `Doesn’t match your “${settings.profileName || "My Feed"}” topics`;
    }

    if (settings.hidePostsWithoutLinks && !post.hasExternalLink) {
      return "Post without an external source link";
    }

    if (
      post.handle &&
      Number.isFinite(rules.limit) &&
      rules.limit > 0
    ) {
      const count = (authorCounts.get(post.handle) || 0) + 1;
      authorCounts.set(post.handle, count);
      if (count > rules.limit) {
        return `More than ${rules.limit} posts from @${post.handle}`;
      }
    }

    return "";
  }

  const BRIEF_STOP_WORDS = new Set([
    "about",
    "after",
    "again",
    "also",
    "been",
    "before",
    "being",
    "from",
    "have",
    "into",
    "just",
    "more",
    "most",
    "over",
    "that",
    "their",
    "there",
    "they",
    "this",
    "through",
    "today",
    "very",
    "what",
    "when",
    "where",
    "which",
    "with",
    "would",
    "your"
  ]);

  function parseBriefMetric(value) {
    const text = String(value || "")
      .trim()
      .toLowerCase()
      .replace(/,/g, "");
    const match = text.match(/(\d+(?:\.\d+)?)\s*([kmb])?/);
    if (!match) return 0;
    const multiplier = { k: 1e3, m: 1e6, b: 1e9 }[match[2]] || 1;
    return Math.round(Number(match[1]) * multiplier);
  }

  function briefTokens(value) {
    return normalizeTerm(value)
      .split(" ")
      .filter(
        (token) =>
          token.length >= 4 &&
          !BRIEF_STOP_WORDS.has(token) &&
          !/^\d+$/.test(token)
      );
  }

  function briefMatchedTopics(post, rules) {
    return rules.topicKeywords.filter((topic) =>
      termMatches(post.normalizedText, topic)
    );
  }

  function postsBelongTogether(left, right) {
    const leftLinks = new Set(left.externalUrls || []);
    if ((right.externalUrls || []).some((url) => leftLinks.has(url))) return true;

    const leftTokens = new Set(left.briefTokens || briefTokens(left.text));
    const sharedTokens = (right.briefTokens || briefTokens(right.text)).filter(
      (token) => leftTokens.has(token)
    );
    if (sharedTokens.length >= 2) return true;

    const leftTopics = new Set(left.matchedTopics || []);
    const sharesTopic = (right.matchedTopics || []).some((topic) =>
      leftTopics.has(topic)
    );
    return sharesTopic && sharedTokens.length >= 1;
  }

  function briefPostScore(post, trustedHandles) {
    const engagement =
      Number(post.engagement?.likes || 0) +
      Number(post.engagement?.reposts || 0) * 2 +
      Number(post.engagement?.replies || 0) * 1.25 +
      Math.sqrt(Number(post.engagement?.views || 0));
    const trusted = trustedHandles.has(post.handle) ? 2.5 : 0;
    return Math.log10(engagement + 1) + trusted;
  }

  function buildBrief(posts, settings, limit = 5) {
    const rules = compileRules(settings);
    const prepared = [...posts]
      .filter((post) => post?.key && post?.text)
      .map((post) => ({
        ...post,
        briefTokens: briefTokens(post.text),
        matchedTopics: briefMatchedTopics(post, rules)
      }));
    const clusters = [];

    for (const post of prepared) {
      const cluster = clusters.find((candidate) =>
        candidate.posts.some((existing) => postsBelongTogether(existing, post))
      );
      if (cluster) cluster.posts.push(post);
      else clusters.push({ posts: [post] });
    }

    return clusters
      .map((cluster) => {
        const handles = new Set(
          cluster.posts.map((post) => post.handle).filter(Boolean)
        );
        const topics = [
          ...new Set(cluster.posts.flatMap((post) => post.matchedTopics))
        ];
        const rankedPosts = [...cluster.posts].sort(
          (left, right) =>
            briefPostScore(right, rules.trustedHandles) -
            briefPostScore(left, rules.trustedHandles)
        );
        const representative = rankedPosts[0];
        const score =
          rankedPosts.reduce(
            (sum, post) => sum + briefPostScore(post, rules.trustedHandles),
            0
          ) +
          Math.max(0, handles.size - 1) * 3 +
          Math.max(0, cluster.posts.length - handles.size) * 0.25;

        return {
          id: rankedPosts.map((post) => post.key).sort().join("|"),
          summary: representative.text,
          topics,
          sourceCount: handles.size || cluster.posts.length,
          postCount: cluster.posts.length,
          score,
          posts: rankedPosts
        };
      })
      .sort((left, right) => right.score - left.score)
      .slice(0, Math.max(1, Number(limit) || 5));
  }

  global.SiftCore = Object.freeze({
    DEFAULT_SETTINGS,
    STARTER_PACKS,
    TESLA_SPACEX_STARTER,
    splitEntries,
    normalizeTerm,
    normalizeHandle,
    parseTerms,
    parseHandles,
    termMatches,
    matchingTerm,
    mergeEntries,
    getStarterPack,
    starterPackIsApplied,
    applyStarterPack,
    getFeedInfo,
    isActiveFeedPath,
    compileRules,
    getConflictingTerms,
    getHideReason,
    parseBriefMetric,
    briefTokens,
    buildBrief
  });
})(globalThis);
