const {
  DEFAULT_SETTINGS,
  normalizeTerm,
  getFeedInfo,
  isActiveFeedPath,
  compileRules,
  getHideReason,
  mergeEntries,
  parseHandles,
  splitEntries,
  parseBriefMetric,
  buildBrief
} = SiftCore;

let settings = { ...DEFAULT_SETTINGS };
let applyTimer;
let lastPath = location.pathname;
let followingAttempted = false;
let isScrolling = false;
let scrollIdleTimer;
let reviewEscapeHandler;
let briefEscapeHandler;
const stackRegistry = new Map();
const briefPostRegistry = new Map();
const MAX_BRIEF_POSTS = 250;

function normalizeHandle(href) {
  if (!href) return "";

  try {
    const path = new URL(href, location.origin).pathname;
    const firstPart = path.split("/").filter(Boolean)[0] || "";
    const reserved = new Set([
      "home",
      "explore",
      "notifications",
      "messages",
      "i",
      "search",
      "settings",
      "compose"
    ]);
    return reserved.has(firstPart.toLowerCase()) ? "" : firstPart.toLowerCase();
  } catch {
    return "";
  }
}

function isExternalLink(anchor) {
  const href = anchor?.getAttribute("href");
  if (!href) return false;

  try {
    const url = new URL(href, location.origin);
    const internalHosts = new Set([
      "x.com",
      "www.x.com",
      "twitter.com",
      "www.twitter.com"
    ]);
    return (
      ["http:", "https:"].includes(url.protocol) &&
      (!internalHosts.has(url.hostname) || url.hostname === "t.co")
    );
  } catch {
    return false;
  }
}

function canonicalUrl(href) {
  if (!href) return "";
  try {
    return new URL(href, location.origin).href;
  } catch {
    return "";
  }
}

function engagementValue(article, testId) {
  const element = article.querySelector(`[data-testid="${testId}"]`);
  const label =
    element?.getAttribute("aria-label") ||
    element?.textContent ||
    element?.querySelector("[aria-label]")?.getAttribute("aria-label") ||
    "";
  return parseBriefMetric(label);
}

function extractPost(article) {
  const userName = article.querySelector('[data-testid="User-Name"]');
  const profileLink = userName?.querySelector('a[href^="/"]');
  const textNodes = Array.from(
    article.querySelectorAll('[data-testid="tweetText"]')
  );
  const text = textNodes
    .map((node) => node.innerText?.trim() || "")
    .filter(Boolean)
    .join(" ");
  const card = article.querySelector('[data-testid="card.wrapper"]');
  const contentText = `${text} ${card?.innerText || ""}`.trim();
  const socialContext =
    article.querySelector('[data-testid="socialContext"]')?.innerText || "";
  const contentLinks = [
    ...textNodes.flatMap((node) => Array.from(node.querySelectorAll("a[href]"))),
    ...Array.from(card?.querySelectorAll("a[href]") || [])
  ];
  const hasExternalLink = contentLinks.some(isExternalLink);
  const externalUrls = [
    ...new Set(
      contentLinks
        .filter(isExternalLink)
        .map((anchor) => canonicalUrl(anchor.getAttribute("href")))
        .filter(Boolean)
    )
  ];
  const handle = normalizeHandle(profileLink?.getAttribute("href"));
  const normalizedText = normalizeTerm(contentText);
  const statusHref =
    article.querySelector('a[href*="/status/"]')?.getAttribute("href") || "";
  const time = article.querySelector("time");
  const hasPromotedLabel = Array.from(article.querySelectorAll("span")).some(
    (element) => element.textContent?.trim().toLowerCase() === "promoted"
  );

  return {
    key: statusHref || `${handle}:${normalizedText.slice(0, 160)}`,
    handle,
    text,
    normalizedText,
    url: canonicalUrl(statusHref),
    timestamp: time?.getAttribute("datetime") || "",
    externalUrls,
    engagement: {
      replies: engagementValue(article, "reply"),
      reposts: engagementValue(article, "retweet"),
      likes: engagementValue(article, "like"),
      views: engagementValue(article, "app-text-transition-container")
    },
    isPromoted: hasPromotedLabel,
    isRepost: /repost(ed)?/i.test(socialContext),
    isQuote: Boolean(article.querySelector('[data-testid="quoteTweet"]')),
    hasExternalLink
  };
}

function safeFeedUrl() {
  return getFeedInfo(settings.feedUrl).url;
}

function setText(element, value) {
  if (element.textContent !== value) element.textContent = value;
}

function withoutHandle(value, handle) {
  return splitEntries(value)
    .filter((entry) => entry.trim().toLowerCase().replace(/^@/, "") !== handle)
    .join("\n");
}

function updateAccountPreference(handle, preference, button) {
  if (!handle || button.disabled) return;
  button.disabled = true;
  setText(button, "…");

  chrome.storage.local.get(
    { hiddenHandles: "", trustedHandles: "" },
    (stored) => {
    if (chrome.runtime.lastError) {
      button.disabled = false;
      setText(button, button.dataset.siftLabel);
      return;
    }

    const targetKey =
      preference === "more" ? "trustedHandles" : "hiddenHandles";
    const oppositeKey =
      preference === "more" ? "hiddenHandles" : "trustedHandles";
    const isActive = parseHandles(stored[targetKey]).has(handle);
    const values = {
      [targetKey]: isActive
        ? withoutHandle(stored[targetKey], handle)
        : mergeEntries(stored[targetKey], `@${handle}`),
      [oppositeKey]: isActive
        ? stored[oppositeKey]
        : withoutHandle(stored[oppositeKey], handle)
    };

    chrome.storage.local.set(values, () => {
      if (chrome.runtime.lastError) {
        button.disabled = false;
        setText(button, button.dataset.siftLabel);
        return;
      }
    });
    }
  );
}

function nativePostActions(article) {
  const nativeAction = article.querySelector(
    '[data-testid="reply"], [data-testid="retweet"], [data-testid="like"], [data-testid="bookmark"]'
  );
  return nativeAction?.closest('[role="group"]') || null;
}

function createPreferenceButton(className, label, title, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className;
  button.dataset.siftLabel = label;
  button.title = title;
  setText(button, label);
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    onClick(button);
  });
  return button;
}

function syncPostPreferenceActions(article, post, shouldShow) {
  let controls = article.querySelector(":scope .sift-post-preferences");
  if (!shouldShow || !post.handle) {
    controls?.remove();
    return;
  }

  const actionRow = nativePostActions(article);
  if (!actionRow) {
    controls?.remove();
    return;
  }

  if (!controls) {
    controls = document.createElement("div");
    controls.className = "sift-post-preferences";
    controls.setAttribute("aria-label", "Sift feed preferences");
    const label = document.createElement("span");
    label.className = "sift-preference-label";
    setText(label, "Sift");

    const lessButton = createPreferenceButton(
      "sift-preference-action sift-auto-flag",
      "Show less",
      "",
      (button) =>
        updateAccountPreference(button.dataset.siftHandle, "less", button)
    );
    const moreButton = createPreferenceButton(
      "sift-preference-action sift-show-more",
      "Show more",
      "",
      (button) =>
        updateAccountPreference(button.dataset.siftHandle, "more", button)
    );
    controls.append(label, lessButton, moreButton);
    actionRow.append(controls);
  }

  const lessButton = controls.querySelector(".sift-auto-flag");
  const moreButton = controls.querySelector(".sift-show-more");
  const lessSelected = parseHandles(settings.hiddenHandles).has(post.handle);
  const moreSelected = parseHandles(settings.trustedHandles).has(post.handle);
  const syncButton = (button, selected) => {
    button.dataset.siftHandle = post.handle;
    button.disabled = false;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
    setText(button, selected ? `✓ ${button.dataset.siftLabel}` : button.dataset.siftLabel);
  };
  syncButton(lessButton, lessSelected);
  syncButton(moreButton, moreSelected);
  lessButton.title = `Show fewer posts like this by hiding @${post.handle}`;
  lessButton.setAttribute(
    "aria-label",
    `Show fewer posts like this; never show @${post.handle}`
  );
  moreButton.title = `Show more posts from @${post.handle}`;
  moreButton.setAttribute(
    "aria-label",
    `Show me more posts from @${post.handle}`
  );
}

function ensureFeedShortcut() {
  const existing = document.querySelector(".sift-feed-shortcut");
  const existingSettings = document.querySelector(".sift-settings-shortcut");

  const primaryNav = document.querySelector(
    'nav[aria-label="Primary"], nav[role="navigation"]'
  );
  if (!primaryNav) return;

  if (!settings.enabled) {
    existing?.remove();
  } else if (!existing) {
    const link = document.createElement("a");
    link.className = "sift-feed-shortcut";
    link.href = safeFeedUrl() || "https://x.com/home";
    const icon = document.createElement("span");
    icon.className = "sift-feed-icon";
    icon.setAttribute("aria-hidden", "true");
    setText(icon, "✦");
    const label = document.createElement("span");
    label.className = "sift-feed-label";
    link.append(icon, label);
    primaryNav.append(link);
  }

  const shortcut = document.querySelector(".sift-feed-shortcut");
  if (shortcut) {
    const feedName = settings.profileName || "My Feed";
    shortcut.href = safeFeedUrl() || "https://x.com/home";
    shortcut.setAttribute("aria-label", `Open ${feedName}`);
    setText(shortcut.querySelector(".sift-feed-label"), feedName);
  }

  if (!existingSettings) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "sift-settings-shortcut";
    button.setAttribute("aria-label", "Open Sift settings");
    const icon = document.createElement("span");
    icon.className = "sift-settings-icon";
    icon.setAttribute("aria-hidden", "true");
    setText(icon, "⚙");
    const label = document.createElement("span");
    label.className = "sift-settings-label";
    setText(label, "Feed settings");
    button.append(icon, label);
    button.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "open-options" });
    });
    primaryNav.append(button);
  }
}

function closeReviewDrawer() {
  document.querySelector(".sift-review-backdrop")?.remove();
  if (reviewEscapeHandler) {
    document.removeEventListener("keydown", reviewEscapeHandler);
    reviewEscapeHandler = undefined;
  }
}

function closeBriefDrawer() {
  document.querySelector(".sift-brief-backdrop")?.remove();
  if (briefEscapeHandler) {
    document.removeEventListener("keydown", briefEscapeHandler);
    briefEscapeHandler = undefined;
  }
}

function rememberBriefPost(post) {
  if (!post.key || !post.text) return;
  briefPostRegistry.delete(post.key);
  briefPostRegistry.set(post.key, post);
  while (briefPostRegistry.size > MAX_BRIEF_POSTS) {
    briefPostRegistry.delete(briefPostRegistry.keys().next().value);
  }
}

function briefItems() {
  return buildBrief([...briefPostRegistry.values()], settings);
}

function briefSummary(value, maxLength = 220) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (text.length <= maxLength) return text;
  return `${text.slice(0, maxLength).replace(/\s+\S*$/, "")}…`;
}

function openBriefDrawer() {
  closeReviewDrawer();
  closeBriefDrawer();

  const items = briefItems();
  const backdrop = document.createElement("div");
  backdrop.className = "sift-brief-backdrop";
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) closeBriefDrawer();
  });

  const drawer = document.createElement("aside");
  drawer.className = "sift-brief-drawer";
  drawer.setAttribute("role", "dialog");
  drawer.setAttribute("aria-label", "Sift Brief");

  const header = document.createElement("header");
  const heading = document.createElement("div");
  const title = document.createElement("h2");
  setText(title, "Sift Brief");
  const subtitle = document.createElement("p");
  setText(
    subtitle,
    `Based on ${briefPostRegistry.size} eligible post${
      briefPostRegistry.size === 1 ? "" : "s"
    } Sift has loaded in this tab.`
  );
  heading.append(title, subtitle);
  const closeButton = document.createElement("button");
  closeButton.type = "button";
  closeButton.className = "sift-brief-close";
  setText(closeButton, "Close");
  closeButton.addEventListener("click", closeBriefDrawer);
  header.append(heading, closeButton);

  const list = document.createElement("div");
  list.className = "sift-brief-list";
  if (items.length === 0) {
    const empty = document.createElement("div");
    empty.className = "sift-brief-empty";
    const emptyTitle = document.createElement("strong");
    setText(emptyTitle, "Your brief is still gathering signal");
    const emptyBody = document.createElement("p");
    setText(
      emptyBody,
      "Scroll your Sift feed to load eligible posts. Brief never fetches posts or sends content anywhere."
    );
    empty.append(emptyTitle, emptyBody);
    list.append(empty);
  } else {
    items.forEach((item, index) => {
      const card = document.createElement("article");
      card.className = "sift-brief-item";
      const meta = document.createElement("span");
      const topicLabel = item.topics.slice(0, 2).join(" · ");
      setText(
        meta,
        `${index + 1} · ${topicLabel || "Your feed"} · ${
          item.sourceCount
        } source${item.sourceCount === 1 ? "" : "s"}`
      );
      const summary = document.createElement("p");
      summary.className = "sift-brief-summary";
      setText(summary, briefSummary(item.summary));
      const sourceRow = document.createElement("div");
      sourceRow.className = "sift-brief-sources";
      for (const post of item.posts.slice(0, 5)) {
        if (!post.url) continue;
        const source = document.createElement("a");
        source.href = post.url;
        source.target = "_blank";
        source.rel = "noopener noreferrer";
        setText(source, post.handle ? `@${post.handle}` : "View post");
        sourceRow.append(source);
      }
      card.append(meta, summary);
      if (sourceRow.childElementCount > 0) card.append(sourceRow);
      list.append(card);
    });
  }

  const footer = document.createElement("footer");
  setText(
    footer,
    "Local summary · ranked by topic fit, independent sources, and activity"
  );
  drawer.append(header, list, footer);
  backdrop.append(drawer);
  briefEscapeHandler = (event) => {
    if (event.key === "Escape") closeBriefDrawer();
  };
  document.addEventListener("keydown", briefEscapeHandler);
  document.body.append(backdrop);
  closeButton.focus();
}

function reasonCategory(reason) {
  if (/promoted/i.test(reason)) return "ads";
  if (/repost/i.test(reason)) return "reposts";
  if (/quote/i.test(reason)) return "quotes";
  if (/blocked phrase/i.test(reason)) return "blocked phrases";
  if (/never-show|hidden account/i.test(reason)) return "blocked accounts";
  if (/doesn’t match|doesn't match|topic/i.test(reason)) return "off-topic";
  if (/external source|without an external/i.test(reason)) return "no source link";
  if (/maximum|per account|author/i.test(reason)) return "author limit";
  return "other";
}

function stackSummary(entries) {
  const counts = new Map();
  for (const entry of entries) {
    const category = reasonCategory(entry.reason);
    counts.set(category, (counts.get(category) || 0) + 1);
  }
  const ranked = [...counts.entries()].sort((a, b) => b[1] - a[1]);
  const top = ranked.slice(0, 2);
  const remainder = ranked.slice(2).reduce((sum, [, count]) => sum + count, 0);
  const parts = top.map(([label, count]) => `${count} ${label}`);
  if (remainder > 0) parts.push(`${remainder} other`);
  return `${entries.length} post${entries.length === 1 ? "" : "s"} filtered · ${parts.join(" · ")}`;
}

function showEntry(entry) {
  entry.article.dataset.siftShowOnce = "true";
  closeReviewDrawer();
  scheduleApply();
}

function openReviewDrawer(stackId) {
  const entries = stackRegistry.get(stackId);
  if (!entries?.length) return;
  closeReviewDrawer();

  const backdrop = document.createElement("div");
  backdrop.className = "sift-review-backdrop";
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) closeReviewDrawer();
  });

  const drawer = document.createElement("aside");
  drawer.className = "sift-review-drawer";
  drawer.setAttribute("role", "dialog");
  drawer.setAttribute("aria-label", "Filtered posts");

  const header = document.createElement("header");
  const heading = document.createElement("div");
  const title = document.createElement("h2");
  setText(title, "Filtered posts");
  const subtitle = document.createElement("p");
  setText(subtitle, stackSummary(entries));
  heading.append(title, subtitle);
  const closeButton = document.createElement("button");
  closeButton.type = "button";
  closeButton.className = "sift-review-close";
  setText(closeButton, "Close");
  closeButton.addEventListener("click", closeReviewDrawer);
  header.append(heading, closeButton);

  const list = document.createElement("div");
  list.className = "sift-review-list";
  for (const entry of entries) {
    const item = document.createElement("article");
    item.className = "sift-review-item";
    const meta = document.createElement("span");
    setText(meta, entry.post.handle ? `@${entry.post.handle}` : "Unknown account");
    const reason = document.createElement("p");
    setText(reason, entry.reason);
    const preview = document.createElement("p");
    setText(preview, entry.post.text || "(no text)");
    const showButton = document.createElement("button");
    showButton.type = "button";
    setText(showButton, "Show this post");
    showButton.addEventListener("click", () => showEntry(entry));
    item.append(meta, reason, preview, showButton);
    list.append(item);
  }

  const footer = document.createElement("footer");
  const showAllButton = document.createElement("button");
  showAllButton.type = "button";
  setText(showAllButton, "Show all in this group");
  showAllButton.addEventListener("click", () => {
    for (const entry of entries) {
      entry.article.dataset.siftShowOnce = "true";
    }
    closeReviewDrawer();
    scheduleApply();
  });
  footer.append(showAllButton);

  drawer.append(header, list, footer);
  backdrop.append(drawer);
  reviewEscapeHandler = (event) => {
    if (event.key === "Escape") closeReviewDrawer();
  };
  document.addEventListener("keydown", reviewEscapeHandler);
  document.body.append(backdrop);
  closeButton.focus();
}

function handlePlaceholderAction(placeholder, article) {
  const stackId = placeholder.dataset.siftStackId;
  if (stackId) {
    openReviewDrawer(stackId);
    return;
  }
  article.dataset.siftShowOnce = "true";
  revealPost(article);
}

function revealPost(article) {
  article.classList.remove("sift-hidden-post");
  article.removeAttribute("data-sift-reason");
  const postKey = article.dataset.siftPostKey;
  for (const placeholder of article.parentElement?.querySelectorAll(
    ":scope > .sift-placeholder"
  ) || []) {
    if (
      placeholder === article.previousElementSibling ||
      (postKey && placeholder.dataset.siftPostKey === postKey)
    ) {
      placeholder.remove();
    }
  }
}

function collapsePost(article, reason) {
  if (article.dataset.siftShowOnce === "true") {
    revealPost(article);
    return;
  }

  article.classList.add("sift-hidden-post");
  article.dataset.siftReason = reason;

  let placeholder = Array.from(article.parentElement?.children || []).find(
    (element) =>
      element.classList.contains("sift-placeholder") &&
      element.dataset.siftPostKey === article.dataset.siftPostKey
  );
  if (!placeholder) placeholder = article.previousElementSibling;
  if (!placeholder?.classList.contains("sift-placeholder")) {
    placeholder = document.createElement("div");
    placeholder.className = "sift-placeholder";

    const reasonText = document.createElement("span");
    reasonText.className = "sift-placeholder-reason";
    placeholder.append(reasonText);

    const showButton = document.createElement("button");
    showButton.type = "button";
    setText(showButton, "Show this post");
    showButton.addEventListener("click", () => {
      handlePlaceholderAction(placeholder, article);
    });
    placeholder.append(showButton);
  }
  placeholder.dataset.siftPostKey = article.dataset.siftPostKey;
  placeholder.classList.remove(
    "sift-placeholder-stack",
    "sift-placeholder-stack-member",
    "sift-placeholder-preserved"
  );
  placeholder.style.removeProperty("height");
  delete placeholder.dataset.siftStackId;
  article.before(placeholder);

  const isStacked =
    placeholder.classList.contains("sift-placeholder-stack") ||
    placeholder.classList.contains("sift-placeholder-stack-member");
  if (!isStacked) {
    const reasonText = placeholder.querySelector(".sift-placeholder-reason");
    if (reasonText) setText(reasonText, `Filtered: ${reason}`);
    const showButton = placeholder.querySelector("button");
    if (showButton) setText(showButton, "Show");
  }
}

function renderStack(entries) {
  if (entries.length < 2) return;
  const first = entries[0];
  const last = entries.at(-1);
  const stackId = `${first.post.key}|${last.post.key}|${entries.length}`;
  stackRegistry.set(stackId, entries);

  const leader = first.article.previousElementSibling;
  if (!leader?.classList.contains("sift-placeholder")) return;
  leader.classList.add("sift-placeholder-stack");
  leader.dataset.siftStackId = stackId;
  setText(
    leader.querySelector(".sift-placeholder-reason"),
    stackSummary(entries)
  );
  setText(leader.querySelector("button"), "Review");

  for (const entry of entries.slice(1)) {
    const placeholder = entry.article.previousElementSibling;
    if (placeholder?.classList.contains("sift-placeholder")) {
      placeholder.classList.add("sift-placeholder-stack-member");
    }
  }
}

function groupHiddenPosts(decisions) {
  stackRegistry.clear();
  document.querySelectorAll(".sift-placeholder").forEach((placeholder) => {
    placeholder.classList.remove(
      "sift-placeholder-stack",
      "sift-placeholder-stack-member"
    );
    delete placeholder.dataset.siftStackId;
  });

  let run = [];
  const flush = () => {
    if (run.length === 0) return;
    if (run.length === 1) {
      const placeholder = run[0].article.previousElementSibling;
      if (placeholder?.classList.contains("sift-placeholder")) {
        const reasonText = placeholder.querySelector(
          ".sift-placeholder-reason"
        );
        if (reasonText) setText(reasonText, `Filtered: ${run[0].reason}`);
        const showButton = placeholder.querySelector("button");
        if (showButton) setText(showButton, "Show");
      }
    } else {
      renderStack(run);
    }
    run = [];
  };

  for (const decision of decisions) {
    if (decision.reason && decision.collapsed) {
      run.push(decision);
    } else {
      flush();
    }
  }
  flush();
}

function tryFollowingTab() {
  if (
    !settings.enabled ||
    !settings.defaultToFollowing ||
    followingAttempted ||
    location.pathname !== "/home"
  ) {
    return;
  }

  const tabs = Array.from(document.querySelectorAll('[role="tab"]'));
  const followingTab = tabs.find(
    (tab) => tab.textContent?.trim().toLowerCase() === "following"
  );

  if (followingTab) {
    followingAttempted = true;
    if (followingTab.getAttribute("aria-selected") !== "true") {
      followingTab.click();
    }
  }
}

function timelineRoot() {
  return (
    document.querySelector('[data-testid="primaryColumn"]') ||
    document.querySelector("main") ||
    document.body
  );
}

function removeStatusChrome() {
  document.querySelector(".sift-status-bar")?.remove();
  document.querySelector(".sift-empty-state")?.remove();
}

function updateFeedChrome(shown, filtered) {
  removeStatusChrome();
  if (!settings.enabled) return;

  const root = timelineRoot();
  if (!root) return;

  const feedInfo = getFeedInfo(settings.feedUrl);
  const usingList =
    feedInfo.isList &&
    feedInfo.isValid &&
    isActiveFeedPath(location.pathname, settings.feedUrl) &&
    location.pathname !== "/home";
  const needsBetterSource =
    shown === 0 &&
    filtered > 0 &&
    settings.requireTopicMatch &&
    !usingList;

  const status = document.createElement("div");
  status.className = "sift-status-bar";
  status.setAttribute("role", "status");

  const copy = document.createElement("div");
  const title = document.createElement("strong");
  setText(title, settings.profileName || "My Feed");
  const detail = document.createElement("span");
  setText(
    detail,
    filtered === 0
      ? `${shown} post${shown === 1 ? "" : "s"} showing`
      : `${shown} showing · ${filtered} filtered`
  );
  copy.append(title, detail);

  const actions = document.createElement("div");
  actions.className = "sift-status-actions";
  const briefButton = document.createElement("button");
  briefButton.type = "button";
  briefButton.className = "sift-status-primary sift-brief-button";
  setText(briefButton, `Brief${briefPostRegistry.size ? ` (${briefPostRegistry.size})` : ""}`);
  briefButton.addEventListener("click", openBriefDrawer);
  actions.append(briefButton);
  const settingsButton = document.createElement("button");
  settingsButton.type = "button";
  setText(settingsButton, "Settings");
  settingsButton.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "open-options" });
  });
  actions.append(settingsButton);

  if (needsBetterSource) {
    const listButton = document.createElement("button");
    listButton.type = "button";
    listButton.className = "sift-status-primary";
    setText(listButton, "Add a List");
    listButton.addEventListener("click", () => {
      window.open("https://x.com/i/lists", "_blank", "noopener");
      chrome.runtime.sendMessage({ type: "open-options" });
    });
    actions.append(listButton);
  } else if (shown === 0 && filtered > 0) {
    const loosenButton = document.createElement("button");
    loosenButton.type = "button";
    loosenButton.className = "sift-status-primary";
    setText(loosenButton, "Show everything");
    loosenButton.addEventListener("click", () => {
      chrome.storage.local.set({ enabled: false });
    });
    actions.append(loosenButton);
  }

  status.append(copy, actions);
  root.prepend(status);

  if (shown === 0 && filtered > 0) {
    const empty = document.createElement("div");
    empty.className = "sift-empty-state";
    const heading = document.createElement("strong");
    const body = document.createElement("p");
    const row = document.createElement("div");

    if (needsBetterSource) {
      setText(heading, "Your rules are ready—X isn’t loading the right posts");
      setText(
        body,
        "Topic filters only keep posts X already shows. Create a focused List of accounts that cover your topics, paste that List URL in Settings, then open the List."
      );
      const createList = document.createElement("button");
      createList.type = "button";
      createList.className = "sift-status-primary";
      setText(createList, "Create an X List");
      createList.addEventListener("click", () => {
        window.open("https://x.com/i/lists", "_blank", "noopener");
      });
      const openSettings = document.createElement("button");
      openSettings.type = "button";
      setText(openSettings, "Paste List in Settings");
      openSettings.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "open-options" });
      });
      const pause = document.createElement("button");
      pause.type = "button";
      setText(pause, "Pause filtering");
      pause.addEventListener("click", () => {
        chrome.storage.local.set({ enabled: false });
      });
      row.append(createList, openSettings, pause);
    } else {
      setText(heading, "No matching posts in this batch");
      setText(
        body,
        "Sift filtered everything currently loaded. Scroll for more posts, widen your topics, or pause filtering."
      );
      const openSettings = document.createElement("button");
      openSettings.type = "button";
      setText(openSettings, "Open settings");
      openSettings.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "open-options" });
      });
      const pause = document.createElement("button");
      pause.type = "button";
      pause.className = "sift-status-primary";
      setText(pause, "Pause filtering");
      pause.addEventListener("click", () => {
        chrome.storage.local.set({ enabled: false });
      });
      row.append(openSettings, pause);
    }

    empty.append(heading, body, row);
    status.after(empty);
  }
}

function clearInlineFiltering() {
  closeReviewDrawer();
  closeBriefDrawer();
  stackRegistry.clear();
  briefPostRegistry.clear();
  removeStatusChrome();
  document
    .querySelectorAll(".sift-placeholder")
    .forEach((placeholder) => placeholder.remove());
  document
    .querySelectorAll(".sift-post-preferences")
    .forEach((controls) => controls.remove());
  document
    .querySelectorAll("article.sift-hidden-post")
    .forEach(revealPost);
}

function cleanupOrphanedPlaceholders() {
  document.querySelectorAll(".sift-placeholder").forEach((placeholder) => {
    const article = placeholder.nextElementSibling;
    if (!article?.matches?.('article[data-testid="tweet"]')) {
      placeholder.remove();
      return;
    }
    const placeholderKey = placeholder.dataset.siftPostKey;
    const articleKey = article.dataset.siftPostKey;
    if (placeholderKey && articleKey && placeholderKey !== articleKey) {
      placeholder.remove();
    }
  });
}

function shouldCollapseNow(article, alreadyHidden) {
  const rect = article.getBoundingClientRect();
  // Never change layout above the viewport — that is what bounced the page.
  if (rect.bottom <= 0) return alreadyHidden;
  return true;
}

function applySettings() {
  if (isScrolling) return;

  document.documentElement.classList.toggle(
    "sift-distraction-free",
    settings.enabled && settings.distractionFree
  );

  ensureFeedShortcut();

  const shouldFilter =
    settings.enabled && isActiveFeedPath(location.pathname, settings.feedUrl);
  if (!shouldFilter) {
    clearInlineFiltering();
    return;
  }

  tryFollowingTab();
  cleanupOrphanedPlaceholders();

  const authorCounts = new Map();
  const rules = compileRules(settings);
  const decisions = [];
  let shown = 0;
  let filtered = 0;

  document
    .querySelectorAll('article[data-testid="tweet"]')
    .forEach((article) => {
      const post = extractPost(article);
      if (article.dataset.siftPostKey !== post.key) {
        revealPost(article);
        article.dataset.siftPostKey = post.key;
        delete article.dataset.siftShowOnce;
      }

      const reason = getHideReason(post, settings, rules, authorCounts);
      const effectiveReason =
        article.dataset.siftShowOnce === "true" ? "" : reason;
      const alreadyHidden = article.classList.contains("sift-hidden-post");
      let collapsed = false;

      if (effectiveReason) {
        syncPostPreferenceActions(article, post, false);
        filtered += 1;
        if (shouldCollapseNow(article, alreadyHidden)) {
          collapsePost(article, effectiveReason);
          collapsed = true;
        } else {
          // Keep above-fold spam temporarily rather than yanking height upward.
          revealPost(article);
        }
      } else {
        revealPost(article);
        shown += 1;
        if (!reason) {
          rememberBriefPost(post);
          syncPostPreferenceActions(article, post, true);
        } else {
          syncPostPreferenceActions(article, post, false);
        }
      }

      decisions.push({
        article,
        post,
        reason: effectiveReason,
        collapsed
      });
    });

  groupHiddenPosts(decisions);
  updateFeedChrome(shown, filtered);
}

function scheduleApply() {
  clearTimeout(applyTimer);
  applyTimer = setTimeout(applySettings, 80);
}

function isSiftNode(node) {
  const element =
    node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
  return Boolean(
    element?.matches?.(
      ".sift-placeholder, .sift-post-preferences, .sift-feed-shortcut, .sift-settings-shortcut, .sift-review-backdrop, .sift-brief-backdrop, .sift-status-bar, .sift-empty-state"
    ) ||
      element?.closest?.(
        ".sift-placeholder, .sift-post-preferences, .sift-feed-shortcut, .sift-settings-shortcut, .sift-review-backdrop, .sift-brief-backdrop, .sift-status-bar, .sift-empty-state"
      )
  );
}

function handleMutations(mutations) {
  const onlySiftChanges = mutations.every((mutation) => {
    if (isSiftNode(mutation.target)) return true;
    const changedNodes = [...mutation.addedNodes, ...mutation.removedNodes];
    return changedNodes.length > 0 && changedNodes.every(isSiftNode);
  });

  if (!onlySiftChanges) scheduleApply();
}

function loadSettings() {
  chrome.storage.local.get(DEFAULT_SETTINGS, (stored) => {
    settings = { ...DEFAULT_SETTINGS, ...stored };
    followingAttempted = false;
    scheduleApply();
  });
}

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") return;

  briefPostRegistry.clear();
  closeBriefDrawer();
  for (const [key, change] of Object.entries(changes)) {
    settings[key] = change.newValue;
  }
  followingAttempted = false;
  scheduleApply();
});

new MutationObserver(handleMutations).observe(document.documentElement, {
  childList: true,
  subtree: true
});

window.addEventListener(
  "scroll",
  () => {
    isScrolling = true;
    clearTimeout(scrollIdleTimer);
    scrollIdleTimer = setTimeout(() => {
      isScrolling = false;
      scheduleApply();
    }, 180);
  },
  { passive: true }
);

setInterval(() => {
  if (location.pathname !== lastPath) {
    lastPath = location.pathname;
    followingAttempted = false;
    scheduleApply();
  }
}, 500);

loadSettings();
