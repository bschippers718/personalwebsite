chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "open-options") {
    chrome.runtime.openOptionsPage();
  }
  if (message?.type === "open-welcome") {
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
  }
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== "install") return;
  chrome.storage.local.get({ onboardingComplete: false }, (stored) => {
    if (stored.onboardingComplete) return;
    chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
  });
});
